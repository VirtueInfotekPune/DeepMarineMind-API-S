import { successResponse, catchResponse, failureResponse } from "../../../core/response";
import { dataLogger, errorLogger, infoLogger } from "../../../core/logger";
import experienceService from "../../../services/candidateDetails/experience";
import { experienceModel } from "../../../models/cabdidateDetails/experience";

export const handleUploadCVCandidate = async (req: any, res: any) => {
    try {
        infoLogger("START: handleUploadCVCandidate function");

        // Extract `sea_experience` from the request body
        const { sea_experience } = req.body;
        if (!Array.isArray(sea_experience) || sea_experience.length === 0) {
            return res.status(400).json(failureResponse({
                handler: "personalDetails",
                messageCode: "E062", // Use a specific code for missing/invalid experience data
                req,
                data: "Sea experience data is missing or invalid",
            }));
        }

        // Transform and validate data
        const experiences = sea_experience.map((exp: any) => ({
            candidate: req.user._id, // Assuming candidate ID is available in `req.user`
            vesselType: exp.vessel_type || "",
            vesselName: exp.vessel_name || "",
            position: exp.rank || "",
            companyName: exp.crewing_agency_and_owner || "",
            startDate: new Date(exp.date_from.split('/').reverse().join('-')),
            endDate: new Date(exp.date_to.split('/').reverse().join('-')),
            cargoType: exp.cargo_type || "",
            rank: exp.rank || "",
            totalDuration: exp.days || "",
            type: "offshore", // Example default value, adjust as needed
            status: 1, // Default active status
        }));

        // Save experiences to the database
        const result = await experienceModel.insertMany(experiences);

        dataLogger("Saved experience data", result);

        // Send success response
        return res.status(200).json(successResponse({
            handler: "personalDetails",
            messageCode: "S029", // Use a specific success code
            req,
            data: result,
        }));

    } catch (error) {
        errorLogger("Error in handleUploadCVCandidate", error);
        return res.status(500).json(catchResponse({
            handler: "personalDetails",
            messageCode: "E063", // Generic error code for internal server errors
            req,
            
        }));
    }
};
