export const USER_ROLE = {
    SUPERADMIN: "superadmin",
    ADMIN: "admin",
    Team : "team"
}