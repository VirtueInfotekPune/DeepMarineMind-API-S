
export const USER_TYPE = {
    CANDIDATE: "candidate",
    RECRUITER: "recruiter",
    SUPERADMIN: "superadmin",
}